from django.core.validators import FileExtensionValidator
from website.validators import validate_image_size

from django import forms
from website.models import Library, Campus, Branch
from django.utils import timezone



LIBRARY_TYPE_CHOICES = [
    ("", "Select Library Type"),
    ("Main Library", "Main Library"),
    ("Satellite Library", "Satellite Library"),
    ("Faculty Library", "Faculty Library"),
    ("Special Collection", "Special Collection"),
    ("Resource Centre", "Resource Centre"),
]



class LibraryForm(forms.ModelForm):
    campus_code = forms.ChoiceField(
        choices=[],
        required=False,
        widget=forms.Select(
            attrs={
                "class": "form-control",
                "id": "campus-select",
            }
        ),

    )



    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Always start with placeholder
        self.fields["campus_code"].choices = [
            ("", "Select Campus")
        ]

        branch = None

        # Case 1: POST request (user submitted form)
        if self.data.get("branch"):
            branch = Branch.objects.filter(
                code=self.data.get("branch")
            ).first()


        # Case 2: Edit existing record
        elif self.instance.pk and self.instance.campus_code:
            campus = Campus.objects.filter(
                campus_code=self.instance.campus_code
            ).select_related("branch").first()

            if campus:
                branch = campus.branch

        # Populate campus choices ONLY if branch is known
        if branch:
            campuses = Campus.objects.filter(branch=branch).order_by("campus_name")
            self.fields["campus_code"].choices += [
                (c.campus_code, c.campus_name) for c in campuses
            ]

        # Branch label
        self.fields["branch"].label_from_instance = lambda obj: obj.name

        # Last verified logic (unchanged)
        today = timezone.now().date()

        # Always prevent future dates
        self.fields["last_verified"].widget.attrs["max"] = today

        # If editing and last_verified exists, lock minimum to stored value
        if self.instance.pk and self.instance.last_verified:
            self.fields["last_verified"].widget.attrs["min"] = self.instance.last_verified

        # If creating and no value yet, default to today
        if not self.instance.pk and not self.initial.get("last_verified"):
            self.fields["last_verified"].initial = today





    def clean_last_verified(self):
        date = self.cleaned_data.get("last_verified")
        today = timezone.now().date()

        if date != today:
            raise forms.ValidationError("Last verified date must be today.")
        return date
    
    def clean_library_code(self):
        code = self.cleaned_data.get("library_code")

        if not code:
            return code

        qs = Library.objects.filter(library_code=code)

        # If editing, exclude current record
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)

        if qs.exists():
            raise forms.ValidationError("Library code already exists.")

        return code




    branch = forms.ModelChoiceField(
        queryset=Branch.objects.all().order_by("name"),
        required=False,
        empty_label="Select Branch",
        widget=forms.Select(attrs={
            "class": "form-control",
            "id": "branch-select",
        }),
    )


    library_type = forms.ChoiceField(
        choices=LIBRARY_TYPE_CHOICES,
        required=False,
        widget=forms.Select(attrs={"class": "form-control"}),
    )

    image = forms.ImageField(
        required=False,
        validators=[
            FileExtensionValidator(["jpg", "jpeg", "png", "webp"]),
            validate_image_size,
        ],
        widget=forms.ClearableFileInput(
            attrs={"class": "form-control"}
        ),
    )


    class Meta:
        model = Library
        fields = [
            "library_code",
            "image",
            "branch",
            "campus_code",
            "library_name",
            "short_name",
            "library_type",
            "address",
            "city",
            "state",
            "postcode",
            "phone",
            "email",
            "website_url",
            "opening_hours",
            "weekend_hours",
            "notes",
            "latitude",
            "longitude",
            "source_url",
            "last_verified",
        ]

        widgets = {
            "library_code": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "e.g. LIB-PP-01"
            }),

            "library_name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Full library name"
            }),

            "short_name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Short name (optional)"
            }),

            "address": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 2,
                "placeholder": "Street address"
            }),

            "city": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "City"
            }),

            "state": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "State"
            }),

            "postcode": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Postcode"
            }),

            "phone": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "e.g. 04-1234567"
            }),

            "email": forms.EmailInput(attrs={
                "class": "form-control",
                "placeholder": "library@example.edu.my"
            }),

            "website_url": forms.URLInput(attrs={
                "class": "form-control",
                "placeholder": "https://library.example.edu.my"
            }),

            "opening_hours": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 2,
                "placeholder": "Mon–Fri: 8.30am – 5.00pm"
            }),

            "weekend_hours": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 2,
                "placeholder": "Sat–Sun: Closed"
            }),

            "notes": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
                "placeholder": "Additional notes (optional)"
            }),

            "latitude": forms.NumberInput(attrs={
                "class": "form-control",
                "step": "any",
                "placeholder": "Latitude"
            }),

            "longitude": forms.NumberInput(attrs={
                "class": "form-control",
                "step": "any",
                "placeholder": "Longitude"
            }),

            "source_url": forms.URLInput(attrs={
                "class": "form-control",
                "placeholder": "Source reference URL"
            }),

            "last_verified": forms.DateInput(attrs={
                "class": "form-control",
                "type": "date"
            }),
        }

