# 🗒️ Changelog

## v1.0.0 – Initial Release
- Added Google login
- Added multi-branch system
- Space browsing
- Real-time availability
- Booking engine with conflict detection
- Approval workflow
- Reporting dashboard
- Bank interface for payments
- Cancellation system
- Email notifications

